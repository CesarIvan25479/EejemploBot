<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;

class webhookController extends Controller
{
    const TOKEN_ANDERCODE = "ANDERCODEPHPAPIMETA";
    const WEBHOOK_URL = "https://devbot.m-net.mx/api/webhook";

    public function validar(Request $request){
        if(isset($request->hub_mode) && isset($request->hub_verify_token)
        && isset($request->hub_challenge) && $request->hub_mode == 'subscribe' && $request->hub_verify_token === self::TOKEN_ANDERCODE){
            return response()->json($request->hub_challenge, 200);
        }else {
            return response()->json(['error' => 'Bad Request'], 403);
        }
    }

    public function recibir(Request $request){
        return $this->recibirMensajes($request->all());
    }

    private function verificarToken(Request $request, $res){
        try{
            $token = $request->hub_verify_token;
            $challenge = $request->hub_challenge;

            if (isset($challenge) && isset($token) == self::TOKEN_ANDERCODE) {
                // $res->send($challenge);
                return response()->json(['challenge' => $challenge], 200);
            }else{
                // $res->status(400)->send();
                return response()->json(['error' => 'Bad Request'], 400);
            }

        }catch(Exception $e){
            return response()->json(['error' => 'Bad Request', 'message' => $e->getMessage()], 400);
        }

    }
    private function recibirMensajes($req){
        try{
            return response()->json('EVENT_RECEIVED',200);
        }catch(Exception $e){
            return response()->json(['EVENT_RECEIVED']);
        }
    }
}
